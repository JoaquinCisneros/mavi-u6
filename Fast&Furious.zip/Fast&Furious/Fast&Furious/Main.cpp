#include <SFML/Graphics.hpp>

int main() {

    sf::RenderWindow window(sf::VideoMode(800, 600), "Fast&Furious");
    window.setFramerateLimit(60);

    sf::CircleShape circle(50); 
    circle.setFillColor(sf::Color::Green);
    circle.setPosition(375, 275); 

    // Velocidad inicial
    float velocidadX = 2.0f;
    float velocidadMax = 10.0f;

    // Bucle principal
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        //Mover el circulo
        sf::Vector2f currentPosition = circle.getPosition();
        circle.setPosition(currentPosition.x + velocidadX, currentPosition.y);

        if (velocidadX > velocidadMax) {
            velocidadX = velocidadMax;
        }

        // Verificar si el c�rculo ha alcanzado el extremo derecho
        if (circle.getPosition().x > 800) {
            // Volver a aparecer en el lado izquierdo con una velocidad mayor
            circle.setPosition(0 , 275);
            velocidadX *= 1.5; // Aumentar la velocidad
        }

        window.clear();

        window.draw(circle);

        window.display();
    }

    return 0;
}
