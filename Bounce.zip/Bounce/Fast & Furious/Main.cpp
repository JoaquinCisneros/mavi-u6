#include <SFML/Graphics.hpp>

int main() {
    // Crear la ventana
    sf::RenderWindow window(sf::VideoMode(800, 600), "Bounce");
    window.setFramerateLimit(60);

    // Configurar el c�rculo
    sf::CircleShape circle(30); 
    circle.setFillColor(sf::Color::Green);
    circle.setPosition(370, 0); // Posici�n inicial

    float gravity = 0.5;  // Aceleraci�n hacia abajo
    float velocity = 0;   // Velocidad inicial

    // Bucle principal
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Actualizar la posici�n y velocidad del c�rculo
        velocity += gravity;
        sf::Vector2f newPosition = circle.getPosition() + sf::Vector2f(0, velocity);
        circle.setPosition(newPosition);

        // Verificar colisi�n con el suelo
        if (circle.getPosition().y + 2 * circle.getRadius() > 600) {
            // Invertir la velocidad para el rebote
            velocity = -velocity;
        }

        window.clear();

        window.draw(circle);

        window.display();
    }

    return 0;
}

