#pragma once

using namespace std;

class game {

public:
	game();
	void loop();
	void 

};