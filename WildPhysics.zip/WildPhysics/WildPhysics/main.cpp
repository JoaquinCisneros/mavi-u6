#include <SFML/Graphics.hpp>
#include <iostream>
#include <sstream>

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "WildPhysics");
    window.setFramerateLimit(60);
    window.setMouseCursorVisible(false);

    // Configuraci�n de la diana
    sf::CircleShape diana(30);
    diana.setFillColor(sf::Color::White);
    diana.setPosition(400 - 30, 300 - 30); // Centrar la diana inicialmente

    // Mira
    sf::CircleShape cursor(10);
    cursor.setFillColor(sf::Color::Red);

    // Puntuaci�n
    sf::Font fuente;

    if (!fuente.loadFromFile("FuenteRegular.ttf")) {
        // Manejar el error si no se puede cargar la fuente
        return -1;
    }

    sf::Text puntuacionText;
    puntuacionText.setFont(fuente);
    puntuacionText.setFillColor(sf::Color::White);
    puntuacionText.setCharacterSize(24);
    puntuacionText.setPosition(10, window.getSize().y - 40);

    float velocidad = 2.0f;
    float direccion = 1.0f;

    int puntuacion = 0;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {

                sf::Vector2f mousePos = cursor.getPosition();

                // Colision
                if (diana.getGlobalBounds().contains(mousePos)) {

                    puntuacion++;

                    // Mover la diana a una nueva posici�n aleatoria
                    float newX = static_cast<float>(rand() % (800 - 2 * 30) + 30);
                    float newY = static_cast<float>(rand() % (600 - 2 * 30) + 30);
                    velocidad = static_cast<float>(rand() % 5) + 1.0f; // Velocidad aleatoria con cada diana
                    if (rand() % 2 == 0) {
                        velocidad *= -1; // Posibilidad de cambiar de sentido
                    }
                    diana.setPosition(newX, newY);
                }
            }
        }

        if (diana.getPosition().x < 0 || diana.getPosition().x + 2 * 30 > 800) {

            // Mover la diana a una nueva posici�n aleatoria
            float newX = static_cast<float>(rand() % (800 - 2 * 30) + 30);
            float newY = static_cast<float>(rand() % (600 - 2 * 30) + 30);
            velocidad = static_cast<float>(rand() % 5) + 1.0f; // Velocidad entre 1 y 5
            if (rand() % 2 == 0) {
                velocidad *= -1; // Posibilidad de velocidad negativa
            }
            diana.setPosition(newX, newY);
        }

        diana.move(velocidad * direccion, 0);

        // El punto de mira sigue el mouse
        cursor.setPosition(sf::Mouse::getPosition(window).x - 10, sf::Mouse::getPosition(window).y - 10);

        // Actualizar el texto de la puntuaci�n
        std::ostringstream ss;
        ss << "Puntuacion: " << puntuacion;
        puntuacionText.setString(ss.str());

        window.clear();

        window.draw(diana);
        window.draw(cursor);
        window.draw(puntuacionText);

        window.display();
    }

    return 0;
}
