#include <SFML/Graphics.hpp>

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Space");
    window.setFramerateLimit(60);

    sf::CircleShape circle(30.0f);
    circle.setFillColor(sf::Color::Green);
    circle.setPosition(400.0f, 300.0f);

    // Velocidad y aceleraci�n en los ejes x e y
    float velocityX = 0.0f;
    float velocityY = 0.0f;
    float accelerationX = 0.1f;
    float accelerationY = 0.0f;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            // Modificar la aceleraci�n con las flechas del teclado
            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Left) {
                    accelerationX -= 0.1f;
                    accelerationY = 0.0f;
                    velocityY = 0.0f;
                }
                else if (event.key.code == sf::Keyboard::Right) {
                    accelerationX += 0.1f;
                    accelerationY = 0.0f;
                    velocityY = 0.0f;
                }
                else if (event.key.code == sf::Keyboard::Up) {
                    accelerationY -= 0.1f;
                    accelerationX = 0.0f;
                    velocityX = 0.0f;
                }
                else if (event.key.code == sf::Keyboard::Down) {
                    accelerationY += 0.1f;
                    accelerationX = 0.0f;
                    velocityX = 0.0f;
                }
            }
        }

        // Actualizar la velocidad con la aceleraci�n
        velocityX += accelerationX;
        velocityY += accelerationY;

        circle.move(velocityX, velocityY);

        // Rebote si toca los bordes
        sf::Vector2f circlePosition = circle.getPosition();
        if (circlePosition.x < 0 || circlePosition.x > 800) {
            velocityX = -velocityX;
        }
        if (circlePosition.y < 0 || circlePosition.y > 600) {
            velocityY = -velocityY;
        }

        window.clear();

        window.draw(circle);

        window.display();
    }

    return 0;
}
